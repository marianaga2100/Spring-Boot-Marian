package org.marian.garciaa.repository;

import org.marian.garciaa.model.Perfil;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PerfilesRepository extends JpaRepository<Perfil, Integer> {

}
